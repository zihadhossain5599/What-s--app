// Replace this with your Firebase config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "yourapp.firebaseapp.com",
  projectId: "yourapp",
  storageBucket: "yourapp.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();

// Login
function login() {
  const email = document.getElementById("email").value;
  const pass = document.getElementById("password").value;
  auth.signInWithEmailAndPassword(email, pass)
    .then(() => location.href = "chat.html")
    .catch(err => alert(err.message));
}

// Signup
function signup() {
  const email = document.getElementById("email").value;
  const pass = document.getElementById("password").value;
  auth.createUserWithEmailAndPassword(email, pass)
    .then(() => alert("Account created!"))
    .catch(err => alert(err.message));
}

// Send message
function sendMessage() {
  const msg = document.getElementById("messageInput").value;
  const user = auth.currentUser;
  if (!msg || !user) return;

  db.collection("messages").add({
    sender: user.email,
    text: msg,
    timestamp: firebase.firestore.FieldValue.serverTimestamp()
  });

  document.getElementById("messageInput").value = "";
}

// Real-time listener
auth.onAuthStateChanged(user => {
  if (user && location.pathname.includes("chat.html")) {
    db.collection("messages").orderBy("timestamp")
      .onSnapshot(snapshot => {
        const messagesDiv = document.getElementById("messages");
        messagesDiv.innerHTML = "";
        snapshot.forEach(doc => {
          const msg = doc.data();
          messagesDiv.innerHTML += `<p><b>${msg.sender}:</b> ${msg.text} <small>${msg.timestamp?.toDate().toLocaleTimeString()}</small></p>`;
        });
      });
  }
});
